package com.javainuse.bankconsumer.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.loadbalancer.LoadBalancerClient;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.javainuse.bankconsumer.greetingservice.GreetingService;

public class ConsumerControllerClient {
	@Autowired
	private LoadBalancerClient loadBalancer;
	
	 @Autowired
	    private GreetingService greetingService;
	 
	    @GetMapping("/get-greeting/{username}")
	    public String getGreeting(Model model, @PathVariable("username") String username) {
	        model.addAttribute("greeting", greetingService.getGreeting(username));
	        return "greeting-view";
	    }
	public void getEmployee() throws RestClientException, IOException {
		ServiceInstance serviceInstance=loadBalancer.choose("customer-producer");
		System.out.println(serviceInstance.getUri());
		String baseUrl=serviceInstance.getUri().toString();
		baseUrl=baseUrl+"/customer";
		System.out.println("++++++++++++++++++++++++++++))))))))))))"+baseUrl);
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<String> response=null;
		try{
		response=restTemplate.exchange(baseUrl,
				HttpMethod.GET, getHeaders(),String.class);
		}catch (Exception ex)
		{System.out.println(ex);
		}
		System.out.println("=====================+++++++++++++++++++++"+response.getBody());
	}

	private static HttpEntity<?> getHeaders() throws IOException {
		HttpHeaders headers = new HttpHeaders();
		headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
		return new HttpEntity<>(headers);
	}

}
