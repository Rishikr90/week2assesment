package com.javainuse.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javainuse.model.Customer;
import com.javainuse.repository.CustomerRepository;
import com.tcs1.model.Student;


@Service
public class CustomerService {
	@Autowired
	CustomerRepository customerRepository;
	
	public List<Customer> getAllCustomer() 
	{
	List<Customer> students = new ArrayList<Customer>();
	customerRepository.findAll().forEach(student -> students.add(student));
	return students;
	}
	
	public Customer getStudentById(int id) 
	{ 
		
		return customerRepository.findById(id).get();
	}
	
	public void saveOrUpdate(Customer customer) 
	{
	    customerRepository.save(customer);
		
	}
	
	public void delete(int custId) 
	{
	customerRepository.deleteById(custId);
	}

}
